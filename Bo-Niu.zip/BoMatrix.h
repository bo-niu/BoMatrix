//
// Created by niubo on 2/29/20.
//

#ifndef BOMATRIX_BOMATRIX_H
#define BOMATRIX_BOMATRIX_H

#include "Matrix.hpp"

typedef Bo::Matrix<double> BoMatrixXd;
typedef Bo::Matrix<int> BoMatrixXi;
typedef Bo::Matrix<float> BoMatrixXf;



#endif //BOMATRIX_BOMATRIX_H